import { Component, OnInit } from '@angular/core';
import { CustomerModule } from '../module/CustomerModule';
import { CustomerService } from '../service/customer.service';

@Component({
  selector: 'app-display',
  templateUrl: './display.component.html',
  styleUrls: ['./display.component.css']
})
export class DisplayComponent implements OnInit {

  customerArray: CustomerModule[];
  customerEdit: CustomerModule;        //for editing the existing data of user
  isEdit: boolean;

  constructor(private customerSer: CustomerService) { 
    this.customerArray = [];
    this.customerEdit = new CustomerModule();
  }

  ngOnInit() {
    this.customerArray = this.customerSer.getCustomer();
  }


  edit(id:number){
    this.isEdit = true;
    this.customerEdit = this.customerSer.edit(id);

  }

  delete(index:number){
    this.customerSer.delete(index);
  }
}
