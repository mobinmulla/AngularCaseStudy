export class CustomerModule{
    id: Number;
    name: String;
    address: String;
    contact: Number;
}