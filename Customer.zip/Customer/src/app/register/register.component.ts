import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import {CustomerModule} from '../module/CustomerModule'
import { CustomerService } from '../service/customer.service';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent{
  @Input () customer: CustomerModule; 
  @Input () isEdit : boolean;
  @Output () edit = new EventEmitter();

  constructor(private customerSer: CustomerService) { 
    this.customer = new CustomerModule();
  }


  add(){
    this.customerSer.add(this.customer);
    this.customer = new CustomerModule();

  }

  update(){
    this.isEdit = false;
    this.customer = new CustomerModule();
    this.edit.emit();
  }
}
