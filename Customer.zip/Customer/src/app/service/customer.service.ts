import { Injectable } from '@angular/core';
import {CustomerModule} from '../module/CustomerModule';
import { Router } from '@angular/router';

@Injectable({
  providedIn: 'root'
})
export class CustomerService {

  customerArray: CustomerModule[];

  constructor(private routes: Router) {
    this.customerArray = [];
   }

   getCustomer(){
     return this.customerArray;
   }

   add(customer: CustomerModule){
     customer.id = Math.floor(Math.random()*100);
     this.customerArray.push(customer);
     this.routes.navigate(['/display']);

   }

   edit(id: number){
     return this.customerArray.find(key => key.id == id);
   }

   delete(index:number){
     this.customerArray.splice(index,1);
   }
}
