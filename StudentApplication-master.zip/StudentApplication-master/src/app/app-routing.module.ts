import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { StudentRegistrationComponent } from '../app/student-registration/student-registration.component';
import {Routes, RouterModule} from '@angular/router';
import { ListOfStudentsComponent } from './list-of-students/list-of-students.component';
import { SortedListComponent } from './sorted-list/sorted-list.component';

const routes: Routes = [
  { path: '', component: StudentRegistrationComponent, pathMatch: 'full' },
  { path: 'student-register', component: StudentRegistrationComponent, pathMatch: 'full' },
  { path: 'list-of-students', component: ListOfStudentsComponent, pathMatch: 'full' },
  { path: 'sorted-list', component: SortedListComponent, pathMatch: 'full' }
];
@NgModule({
  imports: [
    CommonModule,
    RouterModule.forRoot(routes)
  ],
  declarations: [],
  exports: [ RouterModule ]
})
export class AppRoutingModule { }
