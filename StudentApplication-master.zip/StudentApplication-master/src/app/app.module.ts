import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import {FormsModule} from '@angular/forms';

import { AppComponent } from './app.component';
import { AppRoutingModule } from './/app-routing.module';
import { StudentRegistrationComponent } from './student-registration/student-registration.component';
import { ListOfStudentsComponent } from './list-of-students/list-of-students.component';
import { SortedListComponent } from './sorted-list/sorted-list.component';
import { SortedNamePipe } from './sorted-name.pipe';

@NgModule({
  declarations: [
    AppComponent,
    StudentRegistrationComponent,
    ListOfStudentsComponent,
    SortedListComponent,
    SortedNamePipe
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
