import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { StudentService } from '../services/student.service';

@Component({
  selector: 'app-list-of-students',
  templateUrl: './list-of-students.component.html',
  styleUrls: ['./list-of-students.component.css']
})
export class ListOfStudentsComponent implements OnInit {
  students: any[];
  constructor(private router: Router, private studentService: StudentService) { }

  ngOnInit() {
    this.students = this.studentService.getStudentDetails();
  }
  navigateToRegister() {
    this.router.navigate(['/student-register']);
  }
  deleteRecord(index) {
    this.studentService.deleteStudentRecord(index);
  }
  editRecord(index) {
    this.studentService.editStudentRecord(index);
  }
}
