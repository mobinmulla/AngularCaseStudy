import { Injectable } from '@angular/core';
import {Router} from '@angular/router';

@Injectable({
  providedIn: 'root'
})
export class StudentService {
  constructor(private router: Router) { }
  student: any[] = [];
  setStudentDetails(studentDetails: any) {
    this.student.push(studentDetails);
    alert('Registered successfully!');
    this.router.navigate(['/list-of-students']);
  }
  getStudentDetails() {
   return this.student;
  }
  deleteStudentRecord(index: any) {
    this.student.splice(index , 1);
  }
  editStudentRecord(index: any) {
    this.router.navigate(['/student-register'], { queryParams: { index: index }});
  }
  getDetailsOf(index) {
    return this.student[index];
  }
  edit(index, studentDetails) {
    this.student[index] = studentDetails;
    alert('Updated successfully!');
    this.router.navigate(['/list-of-students']);
  }
}
