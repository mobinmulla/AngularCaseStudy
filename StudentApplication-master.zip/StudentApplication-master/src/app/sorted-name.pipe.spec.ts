import { SortedNamePipe } from './sorted-name.pipe';

describe('SortedNamePipe', () => {
  it('create an instance', () => {
    const pipe = new SortedNamePipe();
    expect(pipe).toBeTruthy();
  });
});
