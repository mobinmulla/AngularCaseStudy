import { Component, OnInit } from '@angular/core';
import { StudentService } from '../services/student.service';
import { ActivatedRoute, Router } from '@angular/router';
import {filter} from 'rxjs/operators';

@Component({
  selector: 'app-student-registration',
  templateUrl: './student-registration.component.html',
  styleUrls: ['./student-registration.component.css']
})
export class StudentRegistrationComponent implements OnInit {

  constructor(private studentService: StudentService, private route: ActivatedRoute, private router: Router) { }
  studentDetails = { rollno: '', fname: '', email: '', address: ''};
  paramIndex: any;
  buttonEditStatus = false;
  ngOnInit() {
    if (window.location.search !== '') {
        this.buttonEditStatus = true;
        this.route.queryParams.pipe(
        filter(params => params.index))
        .subscribe(params => {
        console.log(params.index);
        this.paramIndex = params.index;
        this.studentDetails = this.studentService.getDetailsOf(this.paramIndex);
      });
    }
  }
  onSubmit() {
    this.studentService.setStudentDetails(this.studentDetails);
  }
  editRecordFromService() {
    this.studentService.edit(this.paramIndex, this.studentDetails);
  }
}
